
window.onload=function(){
    const loginButton = document.getElementById("login");

loginButton.addEventListener("click", (event) => {
    // console.log("karitk");
    event.preventDefault();
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    fetch('/api/v1/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'

        },
        body: JSON.stringify({ email, password })

    })
        .then(response => response.json())
        .then(data => {

        })
        .catch(error => {
            console.error('Error: ', error);
        });
})}